<table>
	<tr>
		<th><?php _e( 'Enable', 'learnpress' ); ?></th>
		<td><input type="checkbox"></td>
	</tr>
	<tr>
		<th><?php _e('Title', 'learnpress');?></th>
		<td><input type="text"></td>
	</tr>
	<tr>
		<th><?php _e( 'Description', 'learnpress' ); ?></th>
		<td><input type="checkbox"></td>
	</tr>
	<tr>
		<th><?php _e('Live secret key', 'learnpress');?></th>
		<td><input type="text"></td>
	</tr>
    <tr>
        <th><?php _e('Live publish key', 'learnpress');?></th>
        <td><input type="text"></td>
    </tr>

    <tr>
        <th><?php _e( 'Test mode', 'learnpress' ); ?></th>
        <td><input type="checkbox"></td>
    </tr>
    <tr>
        <th><?php _e('Test secret key', 'learnpress');?></th>
        <td><input type="text"></td>
    </tr>
    <tr>
        <th><?php _e('Test publish key', 'learnpress');?></th>
        <td><input type="text"></td>
    </tr>

</table>