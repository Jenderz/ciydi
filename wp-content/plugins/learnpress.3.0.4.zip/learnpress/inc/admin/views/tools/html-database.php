<?php
/**
 * @author  ThimPress
 * @package LearnPress/Admin/Views
 * @version 3.0.0
 */

defined( 'ABSPATH' ) or die();

include_once "database/html-install-sample-data.php";
include_once "database/html-upgrade-database.php";
include_once "database/html-remove-database.php";
include_once "database/html-remove-outdated-data.php";


