<div class="rss-widget">
	<ul>
		<li>
			<p><?php _e( 'No results found', 'learnpress' ) ?></p>
		</li>
	</ul>
</div>