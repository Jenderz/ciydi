<?php
/**
 * Search regexp \'[a-z]+ - [a-z]+\'
 */

/**
 * use http://example.com?debug=yes to execute the code in this file
 */


//add_action( 'plugins_loaded', function ( ) {
//	include_once 'updates/learnpress-update-3.0.0.php';
//	LP_Update_30::upgrade_orders();
//}, 100000 );

